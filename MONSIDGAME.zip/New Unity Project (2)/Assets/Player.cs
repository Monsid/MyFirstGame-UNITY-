﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static int count = 0; //if the counter = 1 instanciate left
    Vector2 pos = Vector2.zero;
    string input;
    string jumpinput;
    SpriteRenderer sprite;
    float height;
    float width;
    Vector3 directionSeperation;
    SpriteRenderer RendSprites;
    public float move;
    public float jump;


    float damagetime;
    float damagetimedur = 1;
    bool damaged = false;

    bool touching;
    bool jumpend;
    bool ontheground;
    [SerializeField]
    float gravity;
    [SerializeField]
    float speedadjustment;
    float speed;
    [SerializeField]
    float attackspeed;
    public SpriteRenderer sr1;
    public SpriteRenderer sr2;

    public static string oppositeattack;
    public static string attackone;
    public static string attacktwo;
    string otherplayer;

    //COOLDOWNS
    public float cooldownone = 1;
    public float cooldowntimerone;
    public float attackdurationone = 0.6f;
    public float attacktimerone;
    public float cooldowntwo = 1;
    public float cooldowntimertwo;
    public float attackdurationtwo = 0.6f;
    public float attacktimertwo;
    public float cooldownthree = 1;
    public float cooldowntimerthree;
    public float attackdurationthree = 0.4f;
    public float attacktimerthree;

    private float inputDirection;//x value of movevector
    private float verticalVelocity;//y value of movevector

    private Vector2 moveVector; //this vector for moving
    private CharacterController control;
    Vector2 gravdirection;

    public static float yGroundPosition;

    public static Sprite p1normal;
    public static Sprite p2normal;
    public static Sprite hurtplayer1;
    public static Sprite hurtplayer2;
    public static Sprite RedFlagCarry;
    public static Sprite BlueFlagCarry;
    public static Sprite redspinattack;
    public static Sprite bluespinattack;

    // Start is called before the first frame update
    void Start()
    {
        height = transform.localScale.y;
        width = transform.localScale.x;
        gravdirection = Vector2.down.normalized;
        ontheground = false;
        touching = false;

        bluespinattack = Resources.Load<Sprite>("PlayerTwoSpinxcf");
        redspinattack = Resources.Load<Sprite>("PlayerOneSpincf");
        p1normal = Resources.Load<Sprite>("PlayerTwoNormalxcf"); 
        p2normal = Resources.Load<Sprite>("PlayerOneNormalxcf");
        hurtplayer1 = Resources.Load<Sprite>("PlayerOneHurtxcf");
        hurtplayer2 = Resources.Load<Sprite>("PlayerTwoHurtxcf");
        RedFlagCarry = Resources.Load<Sprite>("PlayerOneFlagCarriercf");
        BlueFlagCarry = Resources.Load<Sprite>("PlayerTwoFlagCarriercf");
    }

    public void Initial()
    {

        if (count == 0)
        {
            pos = new Vector2(GameManager.topRight.x, 0);
            pos -= Vector2.right * transform.localScale.x;
            input = "LeftRightPlayerOne";
            otherplayer = "LeftRightPlayerTwo";
            jumpinput = "VerticalPlayerOne";
            directionSeperation = Vector3.right;
            attackone = "PlayerOneAttack";
            oppositeattack = "PlayerTwoAttack";
            transform.GetChild(0).transform.name = "SpriteChildOne";
            count++;
        }
        else
        {//place player on left side of screen
            pos = new Vector2(GameManager.topLeft.x, 0);
            pos += Vector2.right * transform.localScale.x;
            input = "LeftRightPlayerTwo";
            otherplayer = "LeftRightPlayerOne";
            jumpinput = "VerticalPlayerTwo";
            directionSeperation = Vector3.left;
            attacktwo = "PlayerTwoAttack";
            oppositeattack = "PlayerOneAttack";
            transform.GetChild(0).transform.name = "SpriteChildTwo";
        }
        
        transform.position = pos;
        transform.name = input;
    }




    // Update is called once per frame
    void Update()
    {

        if (transform.position.x > PlayerBorder.twodpositionright.x || transform.position.x < PlayerBorder.twodpositionleft.x)
        {
            if (input == "LeftRightPlayerOne")
            {
                Vector2 pos = new Vector2(GameManager.topRight.x, 0);
                pos -= new Vector2(5, 0) * transform.localScale.x;
                transform.position = pos;
            }
            if (input == "LeftRightPlayerTwo")
            {
                Vector2 pos = new Vector2(GameManager.topLeft.x, 0);
                pos += new Vector2(5, 0) * transform.localScale.x;
                transform.position = pos;
            }
        }

        //Normaliser/EQUILIBRATER
        if (damaged == false)
        {
            if (input == "LeftRightPlayerOne")
            {
                    sr1 = GameObject.Find("SpriteChildOne").GetComponent<SpriteRenderer>();
                    sr1.sprite = p1normal;

            }
                if (input == "LeftRightPlayerTwo")
                {
                    sr2 = GameObject.Find("SpriteChildTwo").GetComponent<SpriteRenderer>();
                    sr2.sprite = p2normal;
                }
        }

        //FLAGCARRIERS
        if (input == "LeftRightPlayerTwo" && FlagBlue.flagtaken == true)
        {
            sr1 = GameObject.Find("SpriteChildTwo").GetComponent<SpriteRenderer>();
            sr1.sprite = RedFlagCarry;
        }
        if (input == "LeftRightPlayerOne" && FlagRed.flagtaken == true)
        {
            sr2 = GameObject.Find("SpriteChildOne").GetComponent<SpriteRenderer>();
            sr2.sprite = BlueFlagCarry;
        }


        speed = speedadjustment;
        //Jump

        jump = Input.GetAxis(jumpinput) * Time.deltaTime * speed;
        transform.Translate(jump * new Vector2(0, 2));

        //Mario's Gravity

        transform.Translate(gravdirection * gravity * Time.deltaTime);//fall down



        //move left and right
        move = Input.GetAxis(input) * Time.deltaTime * speed;
        transform.Translate(move * Vector2.right);

        //MODIFY SPRITE THAT IS MOVED FURTHEST IN BATTLE
        if (damagetime > 0)
        {
            damagetime -= Time.deltaTime;
        }
        if (damagetime < 0)
        {
            damagetime = 0;
            damaged = false;
        }

        if (damaged == true && damagetime == 0)
        {

            RendSprites = gameObject.GetComponentInChildren<SpriteRenderer>();
            if (transform.name == "LeftRightPlayerTwo")
            {
                RendSprites.sprite = hurtplayer1;
                damagetime = damagetimedur;
            }
            if (transform.name == "LeftRightPlayerOne")
            {
                RendSprites.sprite = hurtplayer2;
                damagetime = damagetimedur;
            }
        }
        //=========================================
    

            //cooldownslaves
            if (cooldowntimerone > 0)
        {
            cooldowntimerone -= Time.deltaTime;
        }
        if (cooldowntimerone < 0)
        {
            cooldowntimerone = 0;
        }
        //---------
        if (cooldowntimertwo > 0)
        {
            cooldowntimertwo -= Time.deltaTime;
        }
        if (cooldowntimertwo < 0)
        {
            cooldowntimertwo = 0;
        }
        //-----------
        if (cooldowntimerthree > 0)
        {
            cooldowntimerthree -= Time.deltaTime;
        }
        if (cooldowntimerthree < 0)
        {
            cooldowntimerthree = 0;
        }


        if (Input.GetButton(attacktwo) && cooldowntimerone == 0)
        {
            
            GameObject.Find("SpriteChildTwo").transform.Rotate(Vector3.back, 150 * Time.deltaTime * gravity);
            GameObject.Find("LeftRightPlayerTwo").transform.Translate(new Vector2(1, 0) * attackspeed * Time.deltaTime);
            sr2 = GameObject.Find("SpriteChildTwo").GetComponent<SpriteRenderer>();
            sr2.sprite = redspinattack;
            attacktimerone = attackdurationone;
            if (attacktimerone > 0)
            {
                attackdurationone -= Time.deltaTime;
            }
            if (attackdurationone < 0)
            {
                cooldowntimerone = cooldownone;//COOLDOWN
                attacktimerone = 0;
                attackdurationone = 0.5f;//attack duration
            }
            

        }

        if (Input.GetButton(attackone) && cooldowntimertwo == 0)
        {
            GameObject.Find("SpriteChildOne").transform.Rotate(Vector3.forward, 150 * Time.deltaTime * gravity); // axis, angle per second * gravity/speed
            GameObject.Find("LeftRightPlayerOne").transform.Translate(new Vector2(-1, 0) * attackspeed * Time.deltaTime);
            sr1 = GameObject.Find("SpriteChildOne").GetComponent<SpriteRenderer>();
            sr1.sprite = bluespinattack;
            attacktimertwo = attackdurationtwo;
            if (attacktimertwo > 0)
            {
                attackdurationtwo -= Time.deltaTime;
            }
            if (attackdurationtwo < 0)
            {
                cooldowntimertwo = cooldowntwo;//COOLDOWN
                attacktimertwo = 0;
                attackdurationtwo = 0.5f;//attack duration
            }

        }
        //if both buttons pressed move both chars
        if (Input.GetButton(attackone) && Input.GetButton(attacktwo) && cooldowntimerthree == 0 || Input.GetButton(attacktwo) && Input.GetButton(attackone) && cooldowntimerthree == 0)
        {
            
            GameObject.Find("SpriteChildOne").transform.Rotate(Vector3.forward, 150 * Time.deltaTime * gravity); // axis, angle per second * gravity/speed
            GameObject.Find("LeftRightPlayerTwo").transform.Translate(new Vector2(1, 0) * attackspeed * Time.deltaTime);
            sr1 = GameObject.Find("SpriteChildOne").GetComponent<SpriteRenderer>();
            sr1.sprite = bluespinattack;

            GameObject.Find("SpriteChildTwo").transform.Rotate(Vector3.back, 150 * Time.deltaTime * gravity);
            GameObject.Find("LeftRightPlayerOne").transform.Translate(new Vector2(-1, 0) * attackspeed * Time.deltaTime);
            sr2 = GameObject.Find("SpriteChildTwo").GetComponent<SpriteRenderer>();
            sr2.sprite = redspinattack;

            attacktimerthree = attackdurationthree;
            if (attacktimerthree > 0)
            {
                attackdurationthree -= Time.deltaTime;
            }
            if (attackdurationthree < 0)
            {
                cooldowntimerthree = cooldownthree;//COOLDOWN
                attacktimerthree = 0;
                attackdurationthree = 0.5f;//attack duration
            }
        }
        //if both buttons release then change state to normal (sprite)
        
        if (Input.GetButtonUp(attacktwo) && Input.GetButtonUp(attackone) || Input.GetButtonUp(attackone) && Input.GetButtonUp(attacktwo))
        {
            sr2 = transform.Find("SpriteChildTwo").GetComponent<SpriteRenderer>();
            sr2.sprite = p2normal;

            sr1 = transform.Find("SpriteChildOne").GetComponent<SpriteRenderer>();
            sr1.sprite = p1normal;

        }

        


    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Grounf")
        {
            gravdirection.y = 0;
            ontheground = true;
            
        }
        if (other.transform.name == otherplayer)
        {
            if (Input.GetButton("PlayerOneAttack"))
            {
                //PlayerOneAttackLeftRightPlayerOne
                //move other player extra
                GameObject.Find("LeftRightPlayerTwo").transform.Translate(new Vector2(-150, 0) * 1 * Time.deltaTime);
                
            }
            if (Input.GetButton("PlayerTwoAttack"))
            {
                //LeftRightPlayerTwoPlayerTwoAttack
                //move other player extra
                GameObject.Find("LeftRightPlayerOne").transform.Translate(new Vector2(+150, 0) * 1 * Time.deltaTime);
                
            }
            transform.position += directionSeperation;
            touching = true;
            speed = 0;

            if (ontheground == false)
            {
                gravdirection.y = -1;
                
                
            }
            else 
            {
                gravdirection.y = 0;
            }

            
        }

    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Grounf")
        {
            gravdirection.y = -1;
            ontheground = false;
        }
        if (other.transform.name == otherplayer)
        {
            damaged = true;
            touching = false;
            speed = speedadjustment;
            if (ontheground == true)
            {
            gravdirection.y = 0;
            }
            else
            {
                gravdirection.y = -1;
            }
        }
    }




}
