﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Grounf : MonoBehaviour
{


    Vector2 pos = Vector2.zero;
    SpriteRenderer sprite;
    public static float thick;
    public static Vector2 levelground;
    float length;
    float placement;


    // Start is called before the first frame update
    void Start()
    {
        transform.position = GameManager.bottomCenter;
        sprite = GetComponent<SpriteRenderer>();
        
        thick = transform.position.y;
        length = transform.position.x;
        placement = 1;
        transform.position = new Vector3(length, thick, placement);
    }

    
    // Update is called once per frame
    void Update()
    {
        
        levelground = new Vector2(length, transform.position.y);
    }
    
}
