﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ceiling : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

        transform.position = new Vector2(0.15f, 5.61f);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.transform.name == "LeftRightPlayerOne")
            
        {
            Debug.Log("touched111");
            other.transform.Translate(new Vector2(0, -150) * 1 * Time.deltaTime);
        }
        if (other.transform.name == "LeftRightPlayerTwo")
        {
            Debug.Log("touched2222");
            other.transform.Translate(new Vector2(0, -150) * 1 * Time.deltaTime);
        }
    }
}
