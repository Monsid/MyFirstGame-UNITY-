﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanvasPlayerSpawner : MonoBehaviour
{
    BoxCollider2D colider;
    // Start is called before the first frame update
    void Start()
    {
        colider = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.transform.name == "LeftRightPlayerTwo")
        {
            //add point(score) to other player and respawn ^
            ScoreBlue.scorevalue++;
            Vector2 pos = new Vector2(GameManager.topLeft.x, 0);
            pos += new Vector2(5, 0) * transform.localScale.x;
            other.transform.position = pos;
        }
        if (other.transform.name == "LeftRightPlayerOne")
        {
            //add point(score) to other player and respawn ^
            ScoreRed.scorevalue++;
            Vector2 pos = new Vector2(GameManager.topRight.x, 0);
            pos -= new Vector2(5, 0) * transform.localScale.x;
            other.transform.position = pos;
        }
    }
}
