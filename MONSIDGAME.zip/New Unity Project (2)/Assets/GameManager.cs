﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    public Player player;
    public Grounf ground;
    public Ceiling ceiling;
    public PlayerBorder border;
    public FlagBlue flagcastleBlue;
    public FlagRed flagcastleRed;

    public static Vector2 topLeft;
    public static Vector2 topRight;
    public static Vector2 bottomCenter;

    // Start is called before the first frame update
    void Start()
    {
        topLeft = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width - (Screen.width - 1), Screen.height));
        topRight = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height));
        bottomCenter = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width / 2, Screen.height - (Screen.height - 1)));

        Player playerOne = Instantiate(player) as Player;
        Player playerTwo = Instantiate(player) as Player;

        PlayerBorder border1 = Instantiate(border) as PlayerBorder;
        PlayerBorder border2 = Instantiate(border) as PlayerBorder;


        border1.Initial();
        border2.Initial();

        playerOne.Initial();
        playerTwo.Initial();

        Instantiate(flagcastleBlue);
        Instantiate(flagcastleRed);

        Instantiate(ground);
        Instantiate(ceiling);
    }


    // Update is called once per frame
    //void Update()
    //{
        
   // }
}

