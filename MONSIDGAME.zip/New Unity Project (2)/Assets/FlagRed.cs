﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlagRed : MonoBehaviour
{
    Vector2 position;
    SpriteRenderer spriterender;

    public static bool flagtaken = false;

    public static Sprite flagged;
    public static Sprite unflagged;
    // Start is called before the first frame update
    void Start()
    {
        spriterender = gameObject.GetComponent<SpriteRenderer>();
        flagged = Resources.Load<Sprite>("PlayerOneFlag");
        unflagged = Resources.Load<Sprite>("NoFlag");
    }
    // Update is called once per frame
    void Update()
    {
        position = Camera.main.ScreenToWorldPoint(new Vector2(95, Screen.height / 2 / 2));
        transform.position = position;
        spriterender.sprite = flagged;

        if (flagtaken == true)
        {
            spriterender.sprite = unflagged;
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.transform.name == "LeftRightPlayerOne")
        {
            flagtaken = true;
        }
        if (other.transform.name == "LeftRightPlayerTwo" && FlagBlue.flagtaken == true)
        {
            FlagBlue.flagtaken = false;
            ScoreRed.scorevalue = ScoreRed.scorevalue + 2;
        }
    }
}
