﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class PlayerBorder : MonoBehaviour
{
    public static int count = 0;
    public static Vector2 twodpositionleft;
    public static Vector2 twodpositionright;
    Vector3 threedposition;
    SpriteRenderer sprite;


    // Start is called before the first frame update
    void Start()
    {
        sprite = gameObject.GetComponent<SpriteRenderer>();
    }

    public void Initial()
    {

        if (count == 0)
        {
            count++;
            transform.name = "border1left";
            twodpositionleft = Camera.main.ScreenToWorldPoint(new Vector2(0, Screen.height / 2));
            threedposition = new Vector3(twodpositionleft.x, twodpositionleft.y, 0);
            
            
        }
        else
        {//place border

            transform.name = "border2right";
            twodpositionright = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height / 2));
            threedposition = new Vector3(twodpositionright.x, twodpositionright.y, 0);
        }
        transform.position = threedposition;

    }

    // Update is called once per frame
    void Update()
    {
        if (transform.name == "border2right") 
        {
            sprite.color = new Color(0f, 0f, 166f);
        }
        if (transform.name == "border1left")
        {
            sprite.color = new Color(166f, 0f, 0f);
        }
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if (transform.name == "border1left")
        {
            if (other.transform.name == "LeftRightPlayerOne")
            {
                other.transform.Translate(new Vector2(+150, 0));
            }
            if (other.transform.name == "LeftRightPlayerTwo")
            {
                //add point(score) to other player and respawn ^
                ScoreRed.scorevalue--;
                Vector2 pos = new Vector2(GameManager.topLeft.x, 0);
                pos += new Vector2(5, 0) * transform.localScale.x;
                other.transform.position = pos;
            }
        }
        if (transform.name == "border2right")
        {
            if (other.transform.name == "LeftRightPlayerTwo")
            {
                other.transform.Translate(new Vector2(-150, 0));
            }
            if (other.transform.name == "LeftRightPlayerOne")
            {
                //add point(score) to other player and respawn ^
                ScoreBlue.scorevalue--;
                Vector2 pos = new Vector2(GameManager.topRight.x, 0);
                pos -= new Vector2 (5, 0) * transform.localScale.x;
                other.transform.position = pos;
            }
        }
    }
}
